## Environment: 
Ubuntu 18LTS 1080Ti

## Package version: 
Python3.6, keras2.1.6, backend is tensorflow-gpu 1.8.0
numpy 1.14.2, matplotlib 2.1.2 


## How to run?

All jupyter file is locate together with train and vali data path.
More model and code details is introduced in jupyter file.
We have two jupyter file *"**Train_CNN_model**"*.ipynb file is used to train and save model,
***"Predict_mdoel.ipynb"*** is used to show the wrong predicted image and predict model. The prediction of output is save as *"**test.txt**"* in local file path.